# TenderGuard AI — Architecture

## Current prototype architecture

```text
User
  │ clicks, searches, submits forms
  ▼
Browser UI (index.html)
  ├── HTML: page structure and forms
  ├── CSS: responsive layout and visual styles
  └── JavaScript: sample records, navigation, demo rules, rendering
          │
          ├── Project/tender records
          ├── Invoice/document checks
          ├── Review alerts
          ├── Progress tracking
          └── Citizen report records
```

## Data flow
1. The browser loads `index.html`.
2. JavaScript initializes fictional project, invoice, and alert records.
3. The UI renders summary cards, tables, and views from those records.
4. A user action may add or update a record in the in-memory demo state.
5. Simple rules can create a review alert when values differ, an invoice ID repeats, or a supporting document is marked missing.
6. The UI refreshes to display the updated demo state.

## Suggested future architecture (not implemented)
- Frontend: React or another maintained UI framework.
- Backend: REST API with server-side validation and role-based access control.
- Database: PostgreSQL for projects, tenders, invoices, milestones, alerts, and citizen reports.
- File storage: access-controlled object storage for authorised documents.
- Audit trail: append-only log of changes and review decisions.
- Optional document extraction: OCR with human verification before values are treated as evidence.
- Optional integrations: only approved public/official APIs, subject to terms and permission.

## Safety, privacy, and limitations
- Sample data is fictional.
- A mismatch is an indicator to review, not evidence of wrongdoing.
- Human reviewers must validate alerts against source documents.
- A real deployment would need authentication, authorization, secure storage, backups, audit logging, privacy review, security testing, and institutional approval.
- No real government API, GPS feed, OCR, or production backend is connected in this prototype.
