# Manual test cases

These checks are intended for a classroom demonstration. The sample outcomes below describe expected rule behaviour; they are not a formal independent test report.

| ID | Action | Expected result |
|---|---|---|
| TC-01 | Open `index.html` in a modern browser | Dashboard loads without needing an account or API key |
| TC-02 | Navigate through Dashboard, Projects, Documents, Alerts, Progress, Citizen Reports, and Reports | Each view opens and navigation remains usable |
| TC-03 | Add a project with required fields | New project appears in the demo UI |
| TC-04 | Add an invoice whose claimed amount differs from its reference amount | A review flag/alert is created |
| TC-05 | Add an invoice with a missing supporting document | A review flag/alert is created |
| TC-06 | Add an invoice using an existing invoice ID | Duplicate identifier is flagged |
| TC-07 | Submit a citizen report with the required fields | Report is accepted into the demo session |
| TC-08 | Resize browser to a narrow/mobile width | Layout remains usable without horizontal overflow where supported by the page design |
| TC-09 | Refresh the page after adding a record | Confirm demo state may reset; do not expect persistent storage |
| TC-10 | Review an alert | Treat it as a prompt for human verification, not proof of fraud |

## Recording results
For each test, record: Pass / Fail, browser and version, steps performed, observed result, and a screenshot if useful. Do not report tests as passed unless you actually run them.
