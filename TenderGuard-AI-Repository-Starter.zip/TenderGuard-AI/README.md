# TenderGuard AI — Prototype

TenderGuard AI is a beginner-friendly demonstration prototype for organising rural development project records, reviewing tender/invoice inconsistencies, tracking project progress, and collecting structured citizen observations.

> **Prototype notice:** This version uses synthetic sample data and browser-side demonstration logic. Alerts are review flags, not proof of fraud. It does not connect to government systems, perform OCR, authenticate users, or store records on a secure backend.

## Features
- Dashboard overview
- Projects and tenders
- Invoice/document consistency checks
- Risk/review alerts
- Project progress tracking
- Citizen reports
- Reports view
- Responsive browser interface

## Requirements
A modern browser such as Chrome, Edge, or Firefox. No installation, package manager, or API key is required.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in your browser.
3. Use the sample records and interactive forms to explore the demo.

For a local web server, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Project structure
```text
TenderGuard-AI/
├── index.html              # Standalone HTML/CSS/JavaScript prototype
├── README.md               # Setup and usage guide
├── LICENSE                 # MIT License
├── .gitignore              # Common local files to exclude
├── data/
│   └── sample-data.json    # Fictional example records for documentation/testing
├── docs/
│   └── ARCHITECTURE.md     # Architecture, data flow, and limitations
└── tests/
    └── TEST_CASES.md       # Manual demonstration/test checklist
```

## Test the prototype
Follow `tests/TEST_CASES.md`. Use fictional data only. Test records created through the UI may exist only in the current browser session and may reset on refresh.

## Publish to GitHub
1. Sign in at https://github.com/ and choose **New repository**.
2. Name it `tenderguard-ai-prototype` and set visibility to **Public**.
3. Create the repository. If you already have these files locally, do not add a second README through GitHub's setup option.
4. Upload the files using **Add file → Upload files**, or use Git locally:

```bash
git init
git add .
git commit -m "Initial TenderGuard AI prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/tenderguard-ai-prototype.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and use the repository URL GitHub actually provides. Git must be installed for the command-line method. Never upload passwords, API keys, private records, or personal information.

## License
Released under the MIT License; see `LICENSE`.
